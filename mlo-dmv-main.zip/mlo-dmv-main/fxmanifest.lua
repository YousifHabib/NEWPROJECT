fx_version "cerulean"
game "gta5"

description "DMV San Andreas"
author "GREENCome"
version "1.1.0"

dependency '/gameBuild:2545'

this_is_a_map "yes"