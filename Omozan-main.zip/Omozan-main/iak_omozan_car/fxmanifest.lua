fx_version 'bodacious'
games { 'rdr3', 'gta5' }
author 'Iakkoise'

