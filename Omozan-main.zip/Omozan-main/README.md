# Omozan

https://www.youtube.com/watch?v=9eY1PUkyL7U

Custom building
custom outfit
retexture boxville4

CREDIT

Mapping : iakko

Discord : https://discord.gg/tqk3kAEr4f
